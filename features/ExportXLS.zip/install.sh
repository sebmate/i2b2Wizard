#!/bin/bash
# Parameter $1 = Directory of install script
# Parameter $2 = Webserver Directory


JQUERYREFERENCEFILE=$2/webclient/default.htm
JQUERYREFERENCECODE="\n<script type=\"text/javascript\" src=\"js-ext/jquery-1.6.1.min.js\"></script>\n<script>var \$j = jQuery.noConflict();</script>\n"

LOADERFILE=$2/webclient/js-i2b2/i2b2_loader.js
LOADERCODE="{ code: \"ExportXLS\",\n\t\t  forceLoading: true,\n\t\t  forceConfigMsg: { params: [] },\n\t\t  forceDir: \"cells/plugins/standard\" \n\t\t},\n\t\t"

# 
# Remove any old installations and copy files to webclient dir
#

rm -rf $2/webclient/js-i2b2/cells/plugins/standard/ExportXLS
cp -R $1/webclient/ $2

#
# Insert JQuery reference to default.html
#

if ! grep -q "<script type=\"text/javascript\" src=\"js-ext/jquery-1.6.1.min.js\"></script>" $JQUERYREFERENCEFILE; then
  sed -e "s|<!-- External libraries -->|&$JQUERYREFERENCECODE|1" \
      -e "s|<!--  External libraries -->|&$JQUERYREFERENCECODE|1" \
	  -i $JQUERYREFERENCEFILE
fi


#	
# Add plugin to list of webclient plugins in i2b2 loader
#

if ! grep -q "{ code: \"ExportXLS\"," $LOADERFILE; then
  sed -e "s|{ code:	\"Timeline\",|$LOADERCODE&|1" \
      -i $LOADERFILE
fi

#sleep 5