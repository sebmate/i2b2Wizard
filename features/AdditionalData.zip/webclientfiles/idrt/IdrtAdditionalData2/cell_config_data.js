// this file contains a list of all files that need to be loaded dynamically for this i2b2 Cell
// every file in this list will be loaded after the cell's Init function is called
{
	files:[
		"IdrtAdditionalData2_ctrlr.js",
		"i2b2_msgs.js"
	],
	css:[ 
		"vwAdditionalData.css"
	],
	config: {
		// additional configuration variables that are set by the system
		short_name: "Additional Data",
		name: "Additional Data",
		description: "Shows detailed information of a patientset.",
		//icons: { size32x32: "AdditionalData_icon_32x32.gif" },
		category: ["plugin","examples"],
		plugin: {
			isolateHtml: false,  // this means do not use an IFRAME
			isolateComm: false,  // this means to expect the plugin to use AJAX communications provided by the framework
			html: {
				source: 'injected_screens.html',
				mainDivId: 'adMain'
			}
		}
	}
}
