/**
 * @projectDescription	Messages used by the IdrtAdditionalData2 cell communicator object.
 * @inherits 			i2b2.IdrtAdditionalData2.cfg
 * @namespace			i2b2.IdrtAdditionalData2.cfg.msgs
 * @author				Robert Lodahl
 * @version 			0.1
 * ----------------------------------------------------------------------------------------
 */


// create the communicator Object
i2b2.IdrtAdditionalData2.ajax = i2b2.hive.communicatorFactory("IdrtAdditionalData2");
i2b2.IdrtAdditionalData2.cfg.msgs = {};
i2b2.IdrtAdditionalData2.cfg.parsers = {};

//================================================================================================== //
i2b2.IdrtAdditionalData2.cfg.msgs.plugin_IdrtAdditionalData2_Refine = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r'+
'<ns6:request xmlns:ns4="http://www.i2b2.org/xsd/cell/crc/psm/1.1/"\r'+
'  xmlns:ns7="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/"\r'+
'  xmlns:ns3="http://www.i2b2.org/xsd/cell/crc/pdo/1.1/"\r'+
'  xmlns:ns5="http://www.i2b2.org/xsd/hive/plugin/"\r'+
'  xmlns:ns2="http://www.i2b2.org/xsd/hive/pdo/1.1/"\r'+
'  xmlns:ns6="http://www.i2b2.org/xsd/hive/msg/1.1/">\r'+
'	<message_header>\n'+
'		{{{proxy_info}}}'+
'		<sending_application>\n'+
'			<application_name>i2b2_QueryTool</application_name>\n'+
'			<application_version>0.2</application_version>\n'+
'		</sending_application>\n'+
'		<sending_facility>\n'+
'			<facility_name>PHS</facility_name>\n'+
'		</sending_facility>\n'+
'		<receiving_application>\n'+
'			<application_name>i2b2_DataRepositoryCell</application_name>\n'+
'			<application_version>0.2</application_version>\n'+
'		</receiving_application>\n'+
'		<receiving_facility>\n'+
'			<facility_name>PHS</facility_name>\n'+
'		</receiving_facility>\n'+
'		<message_type>\n'+
'			<message_code>Q04</message_code>\n'+
'			<event_type>EQQ</event_type>\n'+
'		</message_type>\n'+
'		<security>\n'+
'			<domain>{{{sec_domain}}}</domain>\n'+
'			<username>{{{sec_user}}}</username>\n'+
'			{{{sec_pass_node}}}\n'+
'		</security>\n'+
'		<message_control_id>\n'+
'			<message_num>{{{header_msg_id}}}</message_num>\n'+
'			<instance_num>0</instance_num>\n'+
'		</message_control_id>\n'+
'		<processing_id>\n'+
'			<processing_id>P</processing_id>\n'+
'			<processing_mode>I</processing_mode>\n'+
'		</processing_id>\n'+
'		<accept_acknowledgement_type>messageId</accept_acknowledgement_type>\n'+
'		<project_id>{{{sec_project}}}</project_id>\n'+
'	</message_header>\n'+
'	<request_header>\n'+
'		<result_waittime_ms>{{{result_wait_time}}}000</result_waittime_ms>\n'+
'	</request_header>\n'+
'	<message_body>\n'+
'		<ns3:pdoheader>\n'+
'			<patient_set_limit>{{{patient_limit}}}</patient_set_limit>\n'+
'			<estimated_time>{{{result_wait_time}}}000</estimated_time>\n'+
'			<request_type>getPDO_fromInputList</request_type>\n'+
'		</ns3:pdoheader>\n'+
'		<ns3:request xsi:type="ns3:GetPDOFromInputList_requestType" \n'+
'		  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n'+
'			{{{PDO_Request}}}'+
'		</ns3:request>\n'+
'	</message_body>\n'+
'</ns6:request>';
i2b2.IdrtAdditionalData2.cfg.parsers.plugin_IdrtAdditionalData2_Refine = function(){
	if (!this.error) {
		this.model = [];
	} else {
		this.model = false;
		console.error("[readApprovedEntries] Could not parse() data!");
	}
	return this;
}
i2b2.IdrtAdditionalData2.ajax._addFunctionCall(	"plugin_IdrtAdditionalData2_Refine",
								i2b2.IdrtAdditionalData2.cfg.cellURL + 'getRefinementData',
								i2b2.IdrtAdditionalData2.cfg.msgs.plugin_IdrtAdditionalData2_Refine,
								["PDO_Request"],
								i2b2.IdrtAdditionalData2.cfg.parsers.plugin_IdrtAdditionalData2_Refine);
// ================================================================================================== //
i2b2.IdrtAdditionalData2.cfg.msgs.plugin_IdrtAdditionalData2_Request = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r'+
'<ns6:request xmlns:ns4="http://www.i2b2.org/xsd/cell/crc/psm/1.1/"\r'+
'  xmlns:ns7="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/"\r'+
'  xmlns:ns3="http://www.i2b2.org/xsd/cell/crc/pdo/1.1/"\r'+
'  xmlns:ns5="http://www.i2b2.org/xsd/hive/plugin/"\r'+
'  xmlns:ns2="http://www.i2b2.org/xsd/hive/pdo/1.1/"\r'+
'  xmlns:ns6="http://www.i2b2.org/xsd/hive/msg/1.1/">\r'+
'	<message_header>\n'+
'		{{{proxy_info}}}'+
'		<sending_application>\n'+
'			<application_name>i2b2_QueryTool</application_name>\n'+
'			<application_version>0.2</application_version>\n'+
'		</sending_application>\n'+
'		<sending_facility>\n'+
'			<facility_name>PHS</facility_name>\n'+
'		</sending_facility>\n'+
'		<receiving_application>\n'+
'			<application_name>i2b2_IdrtAdditionalData2Cell</application_name>\n'+
'			<application_version>0.2</application_version>\n'+
'		</receiving_application>\n'+
'		<receiving_facility>\n'+
'			<facility_name>PHS</facility_name>\n'+
'		</receiving_facility>\n'+
'		<message_type>\n'+
'			<message_code>Q04</message_code>\n'+
'			<event_type>EQQ</event_type>\n'+
'		</message_type>\n'+
'		<security>\n'+
'			<domain>{{{sec_domain}}}</domain>\n'+
'			<username>{{{sec_user}}}</username>\n'+
'			{{{sec_pass_node}}}\n'+
'		</security>\n'+
'		<message_control_id>\n'+
'			<message_num>{{{header_msg_id}}}</message_num>\n'+
'			<instance_num>0</instance_num>\n'+
'		</message_control_id>\n'+
'		<processing_id>\n'+
'			<processing_id>P</processing_id>\n'+
'			<processing_mode>I</processing_mode>\n'+
'		</processing_id>\n'+
'		<accept_acknowledgement_type>messageId</accept_acknowledgement_type>\n'+
'		<project_id>{{{sec_project}}}</project_id>\n'+
'	</message_header>\n'+
'	<request_header>\n'+
'		<result_waittime_ms>{{{result_wait_time}}}000</result_waittime_ms>\n'+
'	</request_header>\n'+
'	<message_body>\n'+
'	<ns2:patient_data>\n'+
'	    <ns2:observation_set>\n'+
'		<observation sourcesystem_cd="IdrtAdditionalData2" import_date="2007-11-05T10:04:11.536-05:00" download_date="2007-11-05T10:04:11.536-05:00" update_date="2007-11-05T10:04:11.536-05:00">\n'+
'		    <event_id>{{{requestMasterId}}}</event_id>\n'+
'		    <patient_id>{{{requestResultId}}}</patient_id>\n'+
'		    <concept_cd>Tutorial-I2B2:name</concept_cd>\n'+
'		    <start_date>2007-11-05T10:04:11.536-05:00</start_date>\n'+
'		</observation>\n'+
'	    </ns2:observation_set>\n'+
'	</ns2:patient_data>\n'+
'	</message_body>\n'+
'</ns6:request>';

i2b2.IdrtAdditionalData2.cfg.parsers.plugin_IdrtAdditionalData2_Request = function() {
	if (!this.error) {
		this.model = [];
	} else {
		this.model = false;
		console.error("[readApprovedEntries] Could not parse() data!");
	}
	return this;
}

//Pause AJAX Functions until Plugin exists
i2b2.IdrtAdditionalData2.ajax._addFunctionCall(	"plugin_IdrtAdditionalData2_Request",
								i2b2.IdrtAdditionalData2.cfg.cellURL + 'getAdditionalData', //"http://webservices.i2b2.org/i2b2/rest/IdrtAdditionalData2/getTutorialData",
								i2b2.IdrtAdditionalData2.cfg.msgs.plugin_IdrtAdditionalData2_Request,
								["requestMasterId","requestResultId"],
								i2b2.IdrtAdditionalData2.cfg.parsers.plugin_IdrtAdditionalData2_Request);

