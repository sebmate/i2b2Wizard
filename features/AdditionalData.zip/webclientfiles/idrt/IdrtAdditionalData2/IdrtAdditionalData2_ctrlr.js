/**
 * IDRT AdditionalData v2 web client plugin. This plugin is the successor of version 1 of the Idrt AdditionalData plugin.
 * While version 1 runs completely on the clientside, this version works mainly on the server. This webclient pluign
 * is solely used to send and receive data between client/user and server. Next to presenting the data in a table format
 * it allows the use of several comfort functions like filtering, searching and exporting the data.
 * 
 * The code is seperated into four parts:
 * System and Communication Functions: Functions that allow the communication between server and client
 * Webclient Functions: Additional comfort functions of the webclient
 * Helper Functions: Small functions for achieving common goals
 * Html Creation Functions: Functions that will translate the server response into the webclients table format
 * 
 * @inherits            i2b2
 * @namespace           i2b2.IdrtAdditionalData2
 * @author              Robert Lodahl
 * @version             0.1
 * ----------------------------------------------------------------------------------------
 */

//************************************************ //
//****** SYSTEM AND COMMUNICATION FUNCTIONS ****** //
//************************************************ //

/**
 * 
 */
i2b2.IdrtAdditionalData2.Init = function(loadedDiv) {
	i2b2.IdrtAdditionalData2.view.containerDiv = loadedDiv;
	
	// Initialization
	if (!i2b2.IdrtAdditionalData2.persistentOption) {
		i2b2.IdrtAdditionalData2.persistentOption = { "advsearch": "1",
				"noval": "", "color": "", "charlength": "",
				"summary": "1", "iddisplay": "1", "pdisplay": "1" }
	}
	
	// register DIV as valid DragDrop target for Patient Record Sets (PRS) objects
	var op_trgt = {dropTarget:true};
	i2b2.sdx.Master.AttachType("adDropTarget", "QM", op_trgt);
	i2b2.sdx.Master.AttachType("adDropTarget", "PRS", op_trgt);
	i2b2.sdx.Master.AttachType("adResultView", "CONCPT", op_trgt);
	
	// drop event handlers used by this plugin
	i2b2.sdx.Master.setHandlerCustom("adDropTarget", "QM", "DropHandler", i2b2.IdrtAdditionalData2.qmDropEvent);
	i2b2.sdx.Master.setHandlerCustom("adDropTarget", "PRS", "DropHandler", i2b2.IdrtAdditionalData2.prsDropEvent);
	i2b2.sdx.Master.setHandlerCustom("adResultView", "CONCPT", "DropHandler", i2b2.IdrtAdditionalData2.refineDropEvent);
	
	// Create TabView with Option Tab and append it to the resultView div
	var resultView = document.getElementById('adResultView');
	i2b2.IdrtAdditionalData2.model.tabs = new YAHOO.widget.TabView(resultView);
	i2b2.IdrtAdditionalData2.addOptionTab();
	resultView.children[0].children[0].style.float = "right";	//Put Options Tab on the right side
	resultView.getElementsByClassName("yui-content")[0].id = "adContent";
};

/**
 * 
 */
i2b2.IdrtAdditionalData2.Unload = function() {
	// purge old data
	i2b2.IdrtAdditionalData2.purgeOldTabs();
	i2b2.IdrtAdditionalData2.model = {};
	i2b2.IdrtAdditionalData2.model.responseXML = "";
	i2b2.IdrtAdditionalData2.model.resultId = "";
	i2b2.IdrtAdditionalData2.model.queryMaster = "";
	i2b2.IdrtAdditionalData2.model.filterTable = [];
	try { i2b2.IdrtAdditionalData2.yuiPanel.destroy(); } catch(e) {}
	return true;
};

/**
 * 
 */
i2b2.IdrtAdditionalData2.Resize = function() {
	// Randomly chosen variable to check if data is present in table
	if (i2b2.IdrtAdditionalData2.model.responseXML) {
		var plugViewFrame = document.getElementById("anaPluginViewFrame");
		var contentView = document.getElementById("adContent");
		
		var currHeight = plugViewFrame.style.height;
		contentView.style.height = (parseInt(currHeight) - 84) + "px";
	}
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.qmDropEvent = function(sdxData) {
	//Get the QM id.
	var sdxData = sdxData[0];
	i2b2.IdrtAdditionalData2.model.queryMaster = sdxData.sdxInfo.sdxKeyValue;
	i2b2.IdrtAdditionalData2.model.resultId = "";
	
	i2b2.IdrtAdditionalData2.dropEvent(sdxData);	
};

/**
 * 
 */
i2b2.IdrtAdditionalData2.prsDropEvent = function(sdxData) {
	//Get the QM id and the patientset id.
	var sdxData = sdxData[0];
	i2b2.IdrtAdditionalData2.model.queryMaster = sdxData.origData.QM_id;
	i2b2.IdrtAdditionalData2.model.resultId = sdxData.sdxInfo.sdxKeyValue;
	
	i2b2.IdrtAdditionalData2.dropEvent(sdxData);	
};

/**
 * 
 */
i2b2.IdrtAdditionalData2.dropEvent = function(sdxData) {
	//Change Appearance of the dropTarget after drop.
	$('adDropTarget').style.height = "15px";
	$("adDropTarget").innerHTML = 'Showing: ' + i2b2.h.Escape(sdxData.sdxInfo.sdxDisplayName) + ' - You can still drop another query here.';
	$("adDropTarget").style.background = "#CFB";
	setTimeout("$('adDropTarget').style.background='#DEEBEF'", 250);	

	i2b2.IdrtAdditionalData2.getResults();	
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.refineDropEvent = function(sdxData) {
	if (!i2b2.IdrtAdditionalData2.model.responseXML) {
		alert("No Refinement possible!");
		return;
	}	
	
	var data = sdxData[0];
	var scopedCallback = new i2b2_scopedCallback();
	scopedCallback.scope = this;
	scopedCallback.callback = function(results) {
		if (results.error) {
			console.error("Bad Results from Cell Communicator: ", results);
			i2b2.IdrtAdditionalData2.printErrorMessage();
			return false;
		}
		
		var response = results.refXML.documentElement.lastElementChild.children;
		i2b2.IdrtAdditionalData2.addDataToTabs(response);
	}
	
	// We prepare a query for the server cell to be directly redirected to the crc cell
	// Reasoning: crc cell would need to extract and create exactly the same string query otherwise
	// which is only slightly faster. another query and an extractor would be needed: more time consumption, although
	// the carried data is absolutley the same
	
	var pids = i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children[0].children;
	var pdoData =
	'<input_list>\n' +
	'	<patient_list max="4740992" min="0">\n'
	
	for (var i=0; i < pids.length; i++) {
		pdoData += '   <patient_id index="0">'+pids[i].textContent+'</patient_id>\n';
	}
	
	pdoData +=
	'	</patient_list>\n'+
	'</input_list>\n'+
	'<filter_list>\n'+
	'	<panel>\n' +
	'		<panel_number>1</panel_number>\n' +
	'		<panel_timing>ANY</panel_timing>\n' +
	'		<panel_accuracy_scale>100</panel_accuracy_scale>\n' +
	'		<invert>0</invert>\n' +
	'		<total_item_occurrences>1</total_item_occurrences>\n' +
	'		<item>\n';
	
	if (data.origData.isModifier) {
		var ancestor = data.origData.parent;
		while (ancestor.dim_code != data.origData.applied_path) {
			ancestor = ancestor.parent;
		}
		
		pdoData +=
		'			<hlevel>'+ancestor.level+'</hlevel>\n' +
		'			<item_name>'+ancestor.name+'</item_name>\n' +
		'			<item_key>'+ancestor.key+'</item_key>\n' +
		'			<item_icon>'+ancestor.hasChildren+'</item_icon>\n' +
		'			<tooltip>'+ancestor.tooltip+'</tooltip>\n' +
		'			<class>ENC</class>\n' +
		'			<constrain_by_modifier>\n' +
		'				<modifier_name>'+data.origData.name+'</modifier_name>\n' +
		'				<modifier_key>'+data.origData.key+'</modifier_key>\n' +
		'				<applied_path>'+data.origData.applied_path+'</applied_path>\n' +
		'			</constrain_by_modifier>\n';
	} else {
		pdoData +=
		'			<hlevel>'+data.origData.level+'</hlevel>\n' +
		'			<item_name>'+data.origData.name+'</item_name>\n' +
		'			<item_key>'+data.origData.key+'</item_key>\n' +
		'			<item_icon>'+data.origData.hasChildren+'</item_icon>\n' +
		'			<tooltip>'+data.origData.tooltip+'</tooltip>\n';
	}
	
	pdoData +=
	'			<item_is_synonym>false</item_is_synonym>\n' +
	'		</item>\n' +
	'	</panel>\n' +	
	'</filter_list>\n'+
	'<output_option>\n'+
	'	<observation_set blob="true" onlykeys="false"/>\n'+
	'	<pid_set select="using_filter_list" onlykeys="false"/>\n'+
	'   <concept_set_using_filter_list select="using_filter_list" onlykeys="false"/>\n'+
    '   <modifier_set_using_filter_list select="using_filter_list" onlykeys="false"/>\n'+
	'</output_option>\n';
	
	i2b2.IdrtAdditionalData2.ajax.plugin_IdrtAdditionalData2_Refine("Plugin:IdrtAdditionalData2", {PDO_Request:pdoData}, scopedCallback)
}

/**
 * Main Function :)
 */
i2b2.IdrtAdditionalData2.getResults = function() {
	var requestMasterId = i2b2.IdrtAdditionalData2.model.queryMaster;
	var requestResultId = i2b2.IdrtAdditionalData2.model.resultId;
	
	// Create a Callback processor!
	var scopedCallback = new i2b2_scopedCallback();
	scopedCallback.scope = this;
	scopedCallback.callback = function(results) {
		
		// Check if response is bad - if so create an error output
		if (results.error) {
			console.error("Bad Results from Cell Communicator: ",results);
			i2b2.IdrtAdditionalData2.printErrorMessage();
			return false;
		}

		// Extract data from response message and update model
		i2b2.IdrtAdditionalData2.model.responseXML = results.refXML;
		var response = results.refXML.documentElement.lastElementChild.children; 
		
		// Remove wait message
		document.getElementById('adWait').style.display = 'none';
		document.getElementById('adResultView').style.display = '';
	
		// Set up Filter Arrays for all Tables
		i2b2.IdrtAdditionalData2.model.visList = []
	
		// Load new Tabs
		i2b2.IdrtAdditionalData2.loadTabs();
		
		// Select first Tab
		i2b2.IdrtAdditionalData2.model.tabs.selectTab(1);
	}
	
	// Show a 'please wait' message
	i2b2.IdrtAdditionalData2.printWaitMessage();
	
	// Purge old tabs, but maintain option tab
	if (i2b2.IdrtAdditionalData2.model.visList) i2b2.IdrtAdditionalData2.purgeOldTabs();
	
	// ACTUALLY CALL THE SERVERPLUGIN
	i2b2.IdrtAdditionalData2.ajax.plugin_IdrtAdditionalData2_Request("Plugin:IdrtAdditionalData", {requestMasterId:requestMasterId, requestResultId:requestResultId}, scopedCallback);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.loadTabs = function() {
	if (!i2b2.IdrtAdditionalData2.model.responseXML) return false;
	
	var response = i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children; 

	// Set up the PID-List
	var pidList = i2b2.IdrtAdditionalData2.setupPidList(response[0]);
	
	// Create the tabs
	i2b2.IdrtAdditionalData2.makeNewTabs(pidList, response);
	
	// Correct the size of all tabs
	i2b2.IdrtAdditionalData2.Resize();
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.refreshTabs = function() {
	i2b2.IdrtAdditionalData2.purgeOldTabs();
	i2b2.IdrtAdditionalData2.loadTabs();
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.purgeOldTabs = function() {
	// Remove all Tabs
	var tabList = i2b2.IdrtAdditionalData2.model.tabs.get('tabs')
	while (tabList.length > 1) {
		i2b2.IdrtAdditionalData2.model.tabs.removeTab(tabList[1]);
	}
	
	// Finished if no data was loaded
	if (!i2b2.IdrtAdditionalData2.model.visList) return;
	
	for (var i = 0; i < i2b2.IdrtAdditionalData2.model.visList.length; i++) {
		// Remove all Context Menus. Check for existence for robustness in case of previous error
		var menu = YAHOO.widget.MenuManager.getMenu("adContext_"+i)
		if (menu) menu.destroy();
		
		// Remove Left Click Close Context Menu Listener
		var navButton = document.getElementById("adResultView").children[0].children[1+i]; //Option Tab is 0!
		var tabContent = document.getElementById("adResTable"+i);
		YAHOO.util.Event.removeListener(navButton, "click");
		YAHOO.util.Event.removeListener(tabContent, "click");
	}
	
	// Reset the visList
	i2b2.IdrtAdditionalData2.model.visList = [];
}

//********************************* //
//****** WEBCLIENT FUNCTIONS ****** //
//********************************* //

/**
 * //Adapted Script from http://stackoverflow.com/questions/14267781/sorting-html-table-with-js
 */
i2b2.IdrtAdditionalData2.sortTable = function(table, col) {
	
  // Get body content from table and put it in a array
  var tb = table.tBodies[0],
      tr = Array.prototype.slice.call(tb.rows, 0),
      i;
  
  // Get the current sorting order
  var order = table.tHead.firstElementChild.children[col].getAttribute("order")
  order = -((+order) || -1);
  table.tHead.firstElementChild.children[col].setAttribute("order",order);
  
  // Sort the Table after chosen row with given order
  // Split Sorting between number and string columns
  if (i2b2.IdrtAdditionalData2.isNumber(tr, col)) {
  	tr = tr.sort(function (a, b) {
  		var x = parseFloat(a.cells[col].textContent);
  		var y = parseFloat(b.cells[col].textContent);
  		var value = 0;
  		if (x > y) { value = 1; }
  		else if (x < y) { value = -1; }
  		return order*value;
  	});
  } else {
  	tr = tr.sort(function (a, b) {
          return order *
              (a.cells[col].textContent.localeCompare(b.cells[col].textContent));
      });
  }
  
  // Reappend Rows in correct order
  for(i = 0; i < tr.length; ++i) tb.appendChild(tr[i]);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.filterTable = function(event, table, column, tabId) {
	var tb = table.tBodies[0],
		term = event.target.value,
		useAdvSearch = true;
		i;
		
		tr = Array.prototype.slice.call(tb.rows, 0);
		isNum = i2b2.IdrtAdditionalData2.isNumber(tr, column);//tr[0].cells[column].textContent);
		
	if (i2b2.IdrtAdditionalData2.persistentOption["advsearch"]) {
		var filter = i2b2.IdrtAdditionalData2.advSearch(term, isNum);
	} else {
		var filter = (function(x) {
			if (x.indexOf(term) > -1) { return true; }
			return false;
		});
	}

	for (i = 0; i < tr.length; i++) {
		var rowLength = tr[i].cells.length;
		if (filter(tr[i].cells[column].textContent)) {
			// Only unhide, if no longer filtered by any column
			delete i2b2.IdrtAdditionalData2.model.visList[tabId][column+i*rowLength];
			var unhide = true;
			
			for (var n = 0; n < rowLength; n++) {
				if (i2b2.IdrtAdditionalData2.model.visList[tabId][n+i*rowLength]) {
					unhide = false;
					break;
				}
			}
			
			if (unhide) {
				tr[i].style.display = '';
			}
		} else {
			tr[i].style.display = 'none';
			i2b2.IdrtAdditionalData2.model.visList[tabId][column+i*rowLength] = "1";
		}
	}
	return false;
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.closeContextMenuWithLeftClick = function(e, menu) {
	// Hide ALL context menus if open
	for (var i = 0; i < i2b2.IdrtAdditionalData2.model.visList.length; i++) {
		var imenu = YAHOO.widget.MenuManager.getMenu("adContext_"+i)
		imenu.hide();
	}
	
	// Left-Click Listener overwrites OnClick Listener of the input-fields. We need to call it manually.
	if (e.target.name === "filter") {
		e.target.select();
	} else if (e.target.localName === "img" && e.target.parentElement.localName === "em") {
		// Open currenct menu if save-img was clicked
		menu.moveTo(e.clientX, e.clientY);
		menu.show();
	}
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.exportCsv = function(eventType, eventArgs, tabId) {
	var table = document.getElementById("adTable"+tabId)
	var tb = table.tBodies[0];
	var tr = Array.prototype.slice.call(tb.rows, 0);
	var th = table.tHead.firstChild.cells;
	var i,j;
	
	var csvData = "data:application/vnd.ms-excel,sep=;\n";
	for (i = 0; i < th.length; i++) {
		if (th[i].style.display != "none") {
			csvData += th[i].textContent+";";
		}
	}
	csvData += "\n";
	
	for (i = 0; i < tr.length; i++) {
		var rowLength = tr[i].cells.length;
		if (tr[i].style.display != "none") {
			for (j = 0; j < rowLength; j++) {
				if (tr[i].cells[j].style.display != "none") {
					csvData += tr[i].cells[j].textContent+";";
				}
			}
			csvData += "\n";
		}
	}
	csvData = decode_utf8(csvData);

	var csvDownload = encodeURI(csvData);
	var download = document.createElement("a");
	document.body.appendChild(download);
	download.setAttribute("href", csvDownload);
	download.setAttribute("download", "export.csv");
	download.click();
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.hide = function(eventType, eventArgs, data) {
	var tabId = data[0];
	var subTab = data[1];
	
	var table = document.getElementById("adTable"+tabId)
	var tr = Array.prototype.slice.call(table.tBodies[0].rows, 0);
	var th = Array.prototype.slice.call(table.tHead.rows, 0);

	var i, j;
	var preLength = 1; //PID is always in front of everything else!s
	var ownLength = i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children[subTab+1].children.length;
	for (i = 1; i < subTab+1; i++) {
		preLength += i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children[i].children.length;
	}
	
	// Reset all search fields!
	for (i = preLength; i < preLength+ownLength; i++) {
		var node = document.getElementById(tabId+"input"+i);
		node.setValue("");
		var event = document.createEvent("KeyboardEvent");
		event.target = {value: ""};
		event.initEvent("keyup", true, true);
		node.dispatchEvent(event);
	}
	
	// Clear all lines were this modifier was the only content
	for (i = 0; i < tr.length; i++) {
		//alert("A"+tr[i].cells[preLength].textContent+"A");
		if (tr[i].cells[preLength].textContent != "") {
			tr[i].style.display = 'none';
			i2b2.IdrtAdditionalData2.model.visList[tabId][preLength+i*tr[0].cells.length] = "1";
		}
	}
	
	// Clear all TH of this modifier
	for (i = 0; i < 2; i++) {
		for (j = preLength; j < preLength+ownLength; j++) {
			th[i].cells[j].style.display = 'none';
		}
	}

	// Clear all TR of this modifier
	for (i = 0; i < tr.length; i++) {
		for (j = preLength; j < preLength+ownLength; j++) {
			tr[i].cells[j].style.display = 'none';
		}
	}
	
	var menu = YAHOO.widget.MenuManager.getMenu("adContext_"+tabId);
	var oldItem = YAHOO.widget.MenuManager.getMenuItem("adConItem_"+subTab);
	var newText = "Unhide"+oldItem.cfg.config.text.value.substring(oldItem.cfg.config.text.value.indexOf("ide ")+3);
	var newItem = {id: "adConItem_"+subTab, text: newText, onclick: {fn: i2b2.IdrtAdditionalData2.unhide, obj: data}};
	var itemPos = oldItem.index;
	menu.removeItem(oldItem);
	menu.insertItem(newItem, itemPos);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.unhideAll = function(eventType, eventArgs, idContainer) {
	var tabId = idContainer[0];
	var i;
	for (i = 0; i < idContainer[1].length; i++) {
		i2b2.IdrtAdditionalData2.unhide(eventType, eventArgs, [tabId, idContainer[1][i]]);
	}
}

/**
 * //Invertion of i2b2.IdrtAdditionalData2.hide
 */
i2b2.IdrtAdditionalData2.unhide = function(eventType, eventArgs, data) {
	var tabId = data[0];
	var subTab = data[1];
	
	var table = document.getElementById("adTable"+tabId)
	var tr = Array.prototype.slice.call(table.tBodies[0].rows, 0);
	var th = Array.prototype.slice.call(table.tHead.rows, 0);

	var i, j;

	var preLength = 1; //PID is always in front of everything else
	var ownLength = i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children[subTab+1].children.length;
	for (i = 1; i < subTab+1; i++) {
		preLength += i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children[i].children.length;
	}
	
	// Unhide all TH of this modifier
	for (i = 0; i < 2; i++) {
		for (j = preLength; j < preLength+ownLength; j++) {
			th[i].cells[j].style.display = '';
		}
	}

	// Unhide all TR of this modifier
	for (i = 0; i < tr.length; i++) {
		for (j = preLength; j < preLength+ownLength; j++) {
			tr[i].cells[j].style.display = '';
		}
	}	
	
	// Unhide all lines where this modifier was the only content
	var rowLength = tr[0].cells.length;
	for (i = 0; i < tr.length; i++) {
		if (tr[i].cells[preLength].textContent != "") {
			delete i2b2.IdrtAdditionalData2.model.visList[tabId][preLength+i*rowLength];
			
			var unhide = true;
			
			for (j = 0; j < rowLength; j++) {
				if (i2b2.IdrtAdditionalData2.model.visList[tabId][j+i*rowLength]) {
					unhide = false;
					break;
				}
			}
			
			if (unhide) {
				tr[i].style.display = '';
			}
		}
	}
	
	var menu = YAHOO.widget.MenuManager.getMenu("adContext_"+tabId);
	var oldItem = YAHOO.widget.MenuManager.getMenuItem("adConItem_"+subTab);
	var newText = "Hide"+oldItem.cfg.config.text.value.substring(oldItem.cfg.config.text.value.indexOf("ide ")+3);
	var newItem = {id: "adConItem_"+subTab, text: newText, onclick: {fn: i2b2.IdrtAdditionalData2.hide, obj: data}};
	var itemPos = oldItem.index;
	menu.removeItem(oldItem);
	menu.insertItem(newItem, itemPos);
}

// ****************************** //
// ****** HELPER FUNCTIONS ****** //
// ****************************** //

/**
 * 
 */
i2b2.IdrtAdditionalData2.advSearch = function(term, number) {
	return i2b2.IdrtAdditionalData2.getFilterFunction(term,number,0,term.length);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.getFilterFunction = function(term, number, start, end) {
	var index = term.indexOf("||",start);
	if (index > -1 && index < end) {
		var termA = i2b2.IdrtAdditionalData2.getFilterFunction(term,number,start,index);
		var termB = i2b2.IdrtAdditionalData2.getFilterFunction(term,number,(index+2),end);
		return (function(x) {
			if (termA(x) || termB(x)) {return true;}
			return false;
		});
	}
	
	index = term.indexOf("&&",start);
	if (index > -1 && index < end) {
		var termA = i2b2.IdrtAdditionalData2.getFilterFunction(term,number,start,index-1);
		var termB = i2b2.IdrtAdditionalData2.getFilterFunction(term,number,index+2,end);
		return (function(x) {
			if (termA(x) && termB(x)) {return true;}
			return false;
		});
	} 

	var value;
	
	if (number) {
		index = term.indexOf("<=",start);
		if (index > -1 && index < end) {
			value = parseFloat(term.substring(index+2,end));
			return (function(x) {
				if (parseFloat(x) <= value) { return true; }
				return false
			});
		}
		index = term.indexOf("<",start)
		if (index > -1 && index < end) {
			value = parseFloat(term.substring(index+1,end));
			return (function(x) {
				if (parseFloat(x) < value) { return true; }
				return false
			});
		}
		index = term.indexOf(">=",start)
		if (index > -1 && index < end) {
			value = parseFloat(term.substring(index+2,end));
			return (function(x) {
				if (parseFloat(x) >= value) { return true; }
				return false
			});
		}
		index = term.indexOf(">",start)
		if (index > -1 && index < end) {
			value = parseFloat(term.substring(index+1,end));
			return (function(x) {
				if (parseFloat(x) > value) { return true; }
				return false
			});
		}
	}
		
	index = term.indexOf("=",start)
	if (index > -1 && index < end) {
		value = i2b2.IdrtAdditionalData2.trim(term.substring(index+1,end));
		return (function(x) {
			if (x === value) { return true; }
			return false
		});
	}
	index = term.indexOf("!",start)
	if (index > -1 && index < end) {
		value = i2b2.IdrtAdditionalData2.trim(term.substring(index+1,end));
		return (function(x) {
			if (x.indexOf(value) < 0) { return true; }
			return false
		});
	}
	index = term.indexOf("[filled]",start)
	if (index > -1 && index < end) {
		return (function(x) {
			if (x.length > 0) { return true; }
			return false
		});
	}
	index = term.indexOf("[empty]",start)
	if (index > -1 && index < end) {
		return (function(x) {
			if (x.length <= 0) { return true; }
			return false
		});
	}
	value = i2b2.IdrtAdditionalData2.trim(term.substring(start,end));
	return (function(x) {
		if (x.indexOf(value) > -1) { return true; }
		return false;
	});
}	

/**
 * 
 */
i2b2.IdrtAdditionalData2.trim = function(input) {
    return input.replace(/^\s+|\s+$/gm,'');
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.printWaitMessage = function() {
	document.getElementById('adResultView').style.display = 'none';
	document.getElementById('adError').style.display = '';
	document.getElementById('adWait').style.display = 'block';
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.printErrorMessage = function() {
	document.getElementById('adWait').style.display = '';
	document.getElementById('adError').style.display = 'block';
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.isNumber = function(tr, column) {
	var n, i;
	for (i = 0; i < tr.length; i++) {
		if (tr[i].cells[column].textContent != "") {
			n = tr[i].cells[column].textContent;
			break;
		}
	}
	
	return !isNaN(parseFloat(n)) && isFinite(n);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.percentToHexString = function(value, midvalue) {
	var colValue = value/midvalue;
	
	if (colValue > 2) colValue = 0;
	else if (colValue > 1) colValue = 2 - colValue;
	else if (colValue < 0) colValue = 0;
	
	var colRed = (Math.floor(255*(1-colValue))).toString(16);
	var colGreen = (Math.floor(255*colValue)).toString(16);
	
	colRed = colRed.length == 1 ? "0"+colRed : colRed;
	colGreen = colGreen.length == 1 ? "0"+colGreen : colGreen;
	
	return "#"+colRed+colGreen+"88";
}

//************************************* //
//****** HTML CREATION FUNCTIONS ****** //
//************************************* //

/**
 * 
 */
i2b2.IdrtAdditionalData2.setupPidList = function(pidTab) {
	var i;

	var pidList = {};
	for (i = 0; i < pidTab.children.length; i++) {
		pidList[pidTab.children[i].textContent] = pidTab.children[i].getAttribute("mapped");
	}
		
	return pidList;
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.makeNewTabs = function(pidMap, rawTabs){							
	// Create all needed, additional Tabs for the result Table
	for (var i = 0; i < rawTabs.length; i++) {
		i2b2.IdrtAdditionalData2.addSingleTab(pidMap, rawTabs.namedItem(i));
	}

	// Add Summary Tab if wished
	if (i2b2.IdrtAdditionalData2.persistentOption["summary"]) {
		i2b2.IdrtAdditionalData2.addMultiTab(pidMap, Array.prototype.slice.call(rawTabs, 1, rawTabs.length));
	}
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addSingleTab = function(pidMap, rawTab) {
	if (!rawTab) { return false; }
	
	var visArray = [];
	var tabId = i2b2.IdrtAdditionalData2.model.visList.length;
	i2b2.IdrtAdditionalData2.model.visList.push(visArray);
	
	var pidList = Object.keys(pidMap);
	var tabView = i2b2.IdrtAdditionalData2.model.tabs;
	var j, k;
	
	//------------------------------
	var colorLookup;
	if (i2b2.IdrtAdditionalData2.persistentOption["color"]) {
		colorLookup = i2b2.IdrtAdditionalData2.precalcColorValues([rawTab]);
	}
	
	//------------------------------
	var table = '<table id="adTable'+tabId+'"><thead id="tablehead"><tr>' +
				i2b2.IdrtAdditionalData2.addTableHeaders([rawTab], tabId, -1)[0] +
				i2b2.IdrtAdditionalData2.addTableFilters([rawTab], tabId, -1) +
				'</tr></thead><tbody id="tablebody">';

	//------------------------------
	for (j = 0; j < pidList.length; j++) {	
		var cpid = pidList[j];
		
		if (i2b2.IdrtAdditionalData2.persistentOption["pdisplay"] && i2b2.IdrtAdditionalData2.checkIfSkipable(rawTab, cpid)) {
			continue;
		}
		
		var shownPid;
		if (i2b2.IdrtAdditionalData2.persistentOption["iddisplay"]) {
			shownPid = pidMap[cpid];
		} else {
			shownPid = cpid;
		}
		
		//------------------------------
		var drawdic = {};
		var instanceSet = {};
		for (k = 0; k < rawTab.children.length; k++) {
			drawdic[0+" "+k] = i2b2.IdrtAdditionalData2.filterId(cpid, rawTab.children[k].children, instanceSet);
		}
		
		for (var instanceNum in instanceSet) {
			var times = 1;
			for (k = 0; k < rawTab.children.length; k++) {
				if (drawdic[0+" "+k].hasOwnProperty(instanceNum)) {
					times = times*drawdic[0+" "+k][instanceNum].length;
				}
			}
			instanceSet[instanceNum] = times;
		}
		
		for (var instanceNum in instanceSet) {
			for (var k = 0; k < instanceSet[instanceNum]; k++) {
				table += '<tr><td>' + shownPid + '</td>'+
						 i2b2.IdrtAdditionalData2.addTableRow(rawTab, 0, instanceNum, k, drawdic, colorLookup) +
						 '</tr>';
			}
		}
		
	}
	
	//------------------------------
	table += '</tbody></table>';	
	
	//------------------------------
	tabView.addTab( new YAHOO.widget.Tab({
		label: '<img src="js-i2b2/cells/plugins/idrt/IdrtAdditionalData2/assets/save.png">'+rawTab.getAttribute("name") ,
		content: '<div id="adResTable'+tabId+'" class="adResultTable">' + table + '</div>' ,
		active: false
	}));
	
	//---Create Context Menu for Tab---
	var navButton = document.getElementById("adResultView").children[0];
	navButton = navButton.children[navButton.childElementCount-1];
	var tabContent = document.getElementById("adResTable"+tabId);

	var triggerItems = [navButton, tabContent];
	var menuItems = [{text: "Export as CSV", onclick: {fn: i2b2.IdrtAdditionalData2.exportCsv, obj: tabId}}];
	
	var contextMenu = new YAHOO.widget.ContextMenu(
		"adContext_"+tabId,
		{
			trigger: triggerItems,
			itemdata: menuItems,
			lazyload: true
		}
	);
	
	 YAHOO.util.Event.addListener(triggerItems[0], "click", i2b2.IdrtAdditionalData2.closeContextMenuWithLeftClick, contextMenu);
	 YAHOO.util.Event.addListener(triggerItems[1], "click", i2b2.IdrtAdditionalData2.closeContextMenuWithLeftClick, contextMenu);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addMultiTab = function(pidMap, rawTabs) {
	var visArray = [];
	var tabId = i2b2.IdrtAdditionalData2.model.visList.length;
	i2b2.IdrtAdditionalData2.model.visList.push(visArray);
	
	var pidList = Object.keys(pidMap);
	var tabView = i2b2.IdrtAdditionalData2.model.tabs;
	var j, k, n;
	
	//-----------------------------
	var hasPData = false;
	var hasOnlyPData = false;
	var pValue = -1;
	for (k = 0; k < rawTabs.length; k++) {
		if (rawTabs[k].getAttribute("name") === "Patient Data") {
			pValue = k;
			hasPData = true;
			if (rawTabs.length === 1) hasOnlyPData = true;
			break;
		}
	}
	
	//------------------------------
	var colorLookup;
	if (i2b2.IdrtAdditionalData2.persistentOption["color"]) {
		colorLookup = i2b2.IdrtAdditionalData2.precalcColorValues(rawTabs);
	}
	
	//------------------------------
	var table = '<table id="adTable'+tabId+'"><thead id="tablehead"><tr>';
	var tmp = i2b2.IdrtAdditionalData2.addTableHeaders(rawTabs, tabId, pValue);
	var totalCells = tmp[1];
	table += tmp[0] + i2b2.IdrtAdditionalData2.addTableFilters(rawTabs, tabId, pValue) +
			 '</tr></thead><tbody id="tablebody">';
		
	//------------------------------
	for (j = 0; j < pidList.length; j++) {	
		var cpid = pidList[j];
		
		var shownPid;
		if (i2b2.IdrtAdditionalData2.persistentOption["iddisplay"]) {
			shownPid = pidMap[cpid];
		} else {
			shownPid = cpid;
		}
		
		//------------------------------
		var drawdic = {};
		if (hasPData) {
			for (k = 0; k < rawTabs[pValue].children.length; k++) {
				drawdic[pValue+" "+k] = i2b2.IdrtAdditionalData2.filterId(cpid, rawTabs[pValue].children[k].children, {});
			}
		}
		
		// The pdatatab/tab[0] is always drawn
		var cellsBetween = 0;
		var cellsAfter = hasPData ? totalCells - rawTabs[pValue].children.length - 1 : totalCells -1; //-1 for PID
		
		if (!hasOnlyPData) {
			for (n = 0; n < rawTabs.length; n++) {
				if (n == pValue) continue;
				var instanceSet = {};
				for (k = 0; k < rawTabs[n].children.length; k++) {
					drawdic[n+" "+k] = i2b2.IdrtAdditionalData2.filterId(cpid, rawTabs[n].children[k].children, instanceSet);
				}
				
				for (var instanceNum in instanceSet) {
					var times = 1;
					for (k = 0; k < rawTabs[n].children.length; k++) {
						if (drawdic[n+" "+k].hasOwnProperty(instanceNum)) {
							times = times*drawdic[n+" "+k][instanceNum].length;
						}
					}
					instanceSet[instanceNum] = times;
				}
				
				cellsAfter -= rawTabs[n].children.length;
				for (var instanceNum in instanceSet) {
					for (k = 0; k < instanceSet[instanceNum]; k++) {
						// Draw PID and first tab if it is PDATA tab
						table += '<tr><td>' + shownPid + '</td>';
						if (hasPData) table += i2b2.IdrtAdditionalData2.addTableRow(rawTabs[pValue], pValue, 1, k, drawdic, colorLookup);
						
						// Draw empty cells from other tabs
						for (var i = 0; i < cellsBetween; i++) {
							table += '<td></td>';
						}
						
						// Draw cells from this tab
						table += i2b2.IdrtAdditionalData2.addTableRow(rawTabs[n], n, instanceNum, k, drawdic, colorLookup);
						
						// Draw empty cells from other tabs
						for (var i = 0; i < cellsAfter; i++) {
							table += '<td></td>';
						}
					
						table += '</tr>';
					}
				}
				cellsBetween += rawTabs[n].children.length;
			}
		} else {
			table += '<tr><td>' + shownPid + '</td>' +
					 i2b2.IdrtAdditionalData2.addTableRow(rawTabs[0], 0, 1, k, drawdic, colorLookup); +
					 '</tr>';
		}
	}
	
	//------------------------------
	table += '</tbody></table>';	
	
	//------------------------------
	tabView.addTab( new YAHOO.widget.Tab({
		label: '<img src="js-i2b2/cells/plugins/idrt/IdrtAdditionalData2/assets/save.png">Summary',
		content: '<div id="adResTable'+tabId+'" class="adResultTable">' + table + '</div>' ,
		active: false
	}));
	
	//---Create Context Menu for Tab---
	var navButton = document.getElementById("adResultView").children[0];
	navButton = navButton.children[navButton.childElementCount-1];
	var tabContent = document.getElementById("adResTable"+tabId);

	var triggerItems = [navButton, tabContent];
	var ids = [];
	var menuItems = [{text: "Export as CSV", onclick: {fn: i2b2.IdrtAdditionalData2.exportCsv, obj: tabId}}];
	
	if (!hasOnlyPData) {
		for (n = 0; n < rawTabs.length; n++) {
			if (n == pValue) continue;
			menuItems.push({id: "adConItem_"+n, text: "Hide "+rawTabs[n].getAttribute("name"), onclick: {fn: i2b2.IdrtAdditionalData2.hide, obj: [tabId,n]}});
			ids.push(n);
		}
	}
	
	menuItems.push({text: "Unhide All", onclick: {fn: i2b2.IdrtAdditionalData2.unhideAll, obj: [tabId,ids]}});
	
	var contextMenu = new YAHOO.widget.ContextMenu(
		"adContext_"+tabId,
		{
			trigger: triggerItems,
			itemdata: menuItems,
			lazyload: true
		}
	);
	
	YAHOO.util.Event.addListener(triggerItems[0], "click", i2b2.IdrtAdditionalData2.closeContextMenuWithLeftClick, contextMenu);
	YAHOO.util.Event.addListener(triggerItems[1], "click", i2b2.IdrtAdditionalData2.closeContextMenuWithLeftClick, contextMenu);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addTableRow = function(tab, tabNum, instanceNum, currentNum, dataLookup, colorLookup) {
	var table = "";
	for (var k = 0; k < tab.children.length; k++) {
		var column = tab.children[k];
		var obsForPid = null; // loop vars have to be cleared explicitly in JS
		var instance;
		if (dataLookup[tabNum+" "+k].hasOwnProperty(instanceNum)) {
			instance = Math.floor(currentNum%dataLookup[tabNum+" "+k][instanceNum].length);
			obsForPid = dataLookup[tabNum+" "+k][instanceNum][instance];
		}
		if (!obsForPid) {
			table += '<td></td>';
		} else if (column.getAttribute("valueType") === "-" && i2b2.IdrtAdditionalData2.persistentOption["noval"]) {
			table += '<td>existing</td>';
		} else if (column.getAttribute("valueType") === "n" && i2b2.IdrtAdditionalData2.persistentOption["color"]) {
			var usedColor = i2b2.IdrtAdditionalData2.percentToHexString(parseFloat(obsForPid.lastElementChild.textContent), colorLookup[tabNum+" "+k]);
			table += '<td style="background-color:'+usedColor+'">'+obsForPid.lastElementChild.textContent+'</td>';
		} else if (i2b2.IdrtAdditionalData2.persistentOption["charlength"]) {
			table += '<td title="'+obsForPid.lastElementChild.textContent+'">'+
					 obsForPid.lastElementChild.textContent.substring(0,20) + '</td>';
		} else {
			table += '<td>' + obsForPid.lastElementChild.textContent + '</td>';
		}
	}
	
	return table;
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addDataToTabs = function(tabList) {
	var pidList = i2b2.IdrtAdditionalData2.setupPidList(tabList[0]);
	var origTabs = i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.children;
	
	for (var i = 1; i < tabList.length; i++) {
		var tabName = tabList[i].getAttribute("name");
		var usedTab = null;
		
		for (var j = 1; j < origTabs.length; j++) {
			if (origTabs[j].getAttribute("name") === tabName) {
				usedTab = origTabs[j];
				break;
			}
		}

		if (usedTab != null) {
			for (var j = 0; j < tabList[i].children.length; j++) {
				usedTab.appendChild(tabList[i].children[j]);
			}
		} else {
			i2b2.IdrtAdditionalData2.model.responseXML.documentElement.lastElementChild.appendChild(tabList[i]);
		}
	}

	i2b2.IdrtAdditionalData2.refreshTabs();
	i2b2.IdrtAdditionalData2.model.tabs.selectTab(1);
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addTableHeaders = function(rawTabs, tabId, pValue) {
	var past = 1
	if (pValue != -1) past += rawTabs[pValue].children.length;
	
	var endTable = '';
	var table = '<th order="1" onclick="i2b2.IdrtAdditionalData2.sortTable(adTable'+tabId+',0);"><img src="js-i2b2/cells/plugins/idrt/IdrtAdditionalData2/assets/arrows.png">Patient ID</th>';
	for (var n = 0; n < rawTabs.length; n++) {
		var rawTab = rawTabs[n];
		if (n == pValue) {
			for (var j = 0; j < rawTab.children.length; j++) {
				table += '<th order="1" onclick="i2b2.IdrtAdditionalData2.sortTable(adTable'+tabId+','+(j+1)+');"><img src="js-i2b2/cells/plugins/idrt/IdrtAdditionalData2/assets/arrows.png">' + rawTab.children[j].getAttribute("header") + '</th>';
			}
		} else {
			for (var j = 0; j < rawTab.children.length; j++) {	
				// Contains column-name, current ordering as attribute and script for ordering
				endTable += '<th order="1" onclick="i2b2.IdrtAdditionalData2.sortTable(adTable'+tabId+','+(j+past)+');"><img src="js-i2b2/cells/plugins/idrt/IdrtAdditionalData2/assets/arrows.png">' + rawTab.children[j].getAttribute("header") + '</th>';
			}
			past += rawTab.children.length;
		}
	}
	table += endTable+'</tr><tr>';
	
	return [table, past];
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.addTableFilters = function(rawTabs, tabId, pValue) {
	var past = 1;
	if (pValue != -1) past += rawTabs[pValue].children.length;
	
	var endTable = '';
	var table = '<th><input id="input0" name="filter" type="text" onkeyup="i2b2.IdrtAdditionalData2.filterTable(event,adTable'+tabId+',0,'+tabId+');" /></th>';
	for (var n = 0; n < rawTabs.length; n++) {
		rawTab = rawTabs[n];
		if (n == pValue) {
			for (var j = 0; j < rawTab.children.length; j++) {
				table += '<th><input id="'+tabId+'input'+(1+j)+'" name="filter" type="text" onkeyup="i2b2.IdrtAdditionalData2.filterTable(event,adTable'+tabId+','+(j+1)+','+tabId+');" /></th>';
			}
		} else {
			for (var j = 0; j < rawTab.children.length; j++) {
				endTable += '<th><input id="'+tabId+'input'+(past+j)+'" name="filter" type="text" onkeyup="i2b2.IdrtAdditionalData2.filterTable(event,adTable'+tabId+','+(j+past)+','+tabId+');" /></th>';
			}
			past += rawTab.children.length;
		}
	}
	return table+endTable;
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.precalcColorValues = function(rawTabs) {
	var colorLookup = {};
	
	for (var n = 0; n < rawTabs.length; n++) {
		rawTab = rawTabs[n];
		for (var k = 0; k < rawTab.children.length; k++) {
			column = rawTab.children[k];
			if (column.getAttribute("valueType") === "n") {
				var colMidValue = 0;
				for (var j = 0; j < column.children.length; j++) {
					colMidValue += parseFloat(column.children[j].lastElementChild.textContent);
				}
				colMidValue /= column.children.length;
				colorLookup[n+" "+k] = colMidValue;
			}
		}
	}
	
	return colorLookup;
}

/**
 * 
 */
i2b2.IdrtAdditionalData2.checkIfSkipable = function(rawTab, pid) {
	for (var k = 0; k < rawTab.children.length; k++) {
		if (rawTab.children[k].children.namedItem(pid)) {
			return false;
		}
	}
	return true;
}

/**
 * For a given column we want to get all extract all observations referring to this
 * id (multiple matches possible!). Additionally, we save in a given and empty set
 * all instances which are referred in the matching observations
 * 
 * @in id the id which should be filtered
 * @in array the column which should be crawled through
 * @in instanceSet an empty object to save the appearing instance numbers
 */
i2b2.IdrtAdditionalData2.filterId = function(id, array, instanceSet) {
	result = {};
	for (var idx = 0; idx < array.length; idx++) {
		// Do not use namedItem as we could have several objects with the same id
		if (array[idx].getAttribute("id") === id) {
			var instanceNum = array[idx].children[2].textContent;
			if (!result[instanceNum]) {
				result[instanceNum] = [];
				instanceSet[instanceNum] = 1;
			}
			result[instanceNum].push(array[idx]);
		}
	}
	return result;
}

/**
 * This function is responsible for creating the Option Tab which is located on the most right side of
 * the TabListView. Initially the a table (for styling purposes) is creating containing buttons-divs
 * and descriptions. After that the buttons a created via a YUI buttongroup (a set of excluding
 * buttons) and their standardvalue is set. The buttons are also linked with the ValueChangEvent,
 * which will just change the PersistentOption controlled by this button (=> onClick Event). Finally
 * The Refresh all buttons-button is created which will just call a method for reloading the tables
 * onClick. 
 */
i2b2.IdrtAdditionalData2.addOptionTab = function() {
	var table = '<table><tr><td class="adOptBt"><div id="adOptSearch"><div></td><td class="adOptText">Allow the use of math and logical operators in search fields</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptPatientDisplay"><div></td><td class="adOptText">Hide patients in tabs where they do not feature any symptom</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptNoValue"><div></td><td class="adOptText">Display exact sympton (default) or "exists" for observations without a value</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptIdDisplay"><div></td><td class="adOptText">Show the mapped (default) or hive patient id</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptNumValues"><div></td><td class="adOptText">Color numerical columns based on their average value</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptSummaryTab"><div></td><td class="adOptText">Display summary tab (combining all other tabs)</td></tr>' +
				'<tr><td class="adOptBt"><div id="adOptCharLength"><div></td><td class="adOptText">Reduce the maximal text size in any table cell to 20 characters</td></tr>' +
				'</table><div id="adApplyButton"></div>';
	
	var valueChangeEvent = (function(event) {
		var option = event.newValue.get('name');
		var value = event.newValue.get('value');
		
		i2b2.IdrtAdditionalData2.persistentOption[option] = value;
	});
	
	var option = new YAHOO.widget.ButtonGroup({
		id: "optadvsearch",
		name: "advsearch",
		container: "adOptSearch"
	});
	
	var activeButton = (i2b2.IdrtAdditionalData2.persistentOption["advsearch"]) ? true : false;
	option.addButtons([
	   {label: "Yes", value: "1", checked: activeButton},
	   {label: "No", value: "", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optpatientdisplay",
		name: "pdisplay",
		container: "adOptPatientDisplay"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["pdisplay"]) ? true : false;
	option.addButtons([
	   {label: "Yes", value: "1", checked: activeButton},
	   {label: "No", value: "", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optnovalue",
		name: "noval",
		container: "adOptNoValue"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["noval"]) ? false : true;
	option.addButtons([
	   {label: "Show Full Names", value: "", checked: activeButton},
	   {label: "Show Only Exists", value: "1", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optiddisplay",
		name: "iddisplay",
		container: "adOptIdDisplay"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["iddisplay"]) ? true : false;
	option.addButtons([
	   {label: "Show Mapped Id", value: "1", checked: activeButton},
	   {label: "Show Hive Id", value: "", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optnumvalues",
		name: "color",
		container: "adOptNumValues"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["color"]) ? false : true;
	option.addButtons([
	   {label: "No Coloring", value: "", checked: activeButton},
	   {label: "Color Numerical Values", value: "1", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optsummarytab",
		name: "summary",
		container: "adOptSummaryTab"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["summary"]) ? true : false;
	option.addButtons([
	   {label: "Show Summary Tab", value: "1", checked: activeButton},
	   {label: "Hide Summary Tab", value: "", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	option = new YAHOO.widget.ButtonGroup({
		id: "optcharlength",
		name: "charlength",
		container: "adOptCharLength"
	});
	
	activeButton = (i2b2.IdrtAdditionalData2.persistentOption["charlength"]) ? false : true;
	option.addButtons([
	   {label: "Unlimited Length", value: "", checked: activeButton},
	   {label: "Limited to Length of 20", value: "1", checked: !activeButton}
	]);
	
	option.subscribe("checkedButtonChange", valueChangeEvent);
	
	i2b2.IdrtAdditionalData2.model.tabs.addTab( new YAHOO.widget.Tab({
		label: "Options",
		content: table,
		active: true
	}));
	
	option = new YAHOO.widget.Button({
			id: "applyOptionsInstant",
			type: "button",
			label: "Refresh current Tabs",
			container: "adApplyButton"
	});
	
	option.on("click", i2b2.IdrtAdditionalData2.refreshTabs);
}