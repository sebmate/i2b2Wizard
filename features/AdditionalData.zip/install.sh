#!/bin/bash

# ==================================================================================================
# installAdditionalData() 
# ==================================================================================================

installAdditionalData() {

	getIP

	dialog --colors --backtitle "$BACKTITLE" --infobox "AdditionalData: Copying web services files ..." 5 60
	sleep 1

	# i2b2 1.6:

	if [ -d "$JBOSS_HOME/server/default/deploy/i2b2.war/WEB-INF/services" ]; then  
		cp $MY_PATH/features/temp/AdditionalData/serverfiles/IdrtAdditionalData.aar $JBOSS_HOME/server/default/deploy/i2b2.war/WEB-INF/services
		cp $MY_PATH/features/temp/AdditionalData/serverfiles/IdrtAdditionalData-EJB.jar $JBOSS_HOME/server/default/deploy/i2b2.war/WEB-INF/lib
	fi

	# i2b2 1.7:

	if [ -d "$JBOSS_HOME/standalone/deployments/i2b2.war/WEB-INF/services" ]; then  
		cp $MY_PATH/features/temp/AdditionalData/serverfiles/IdrtAdditionalData.aar $JBOSS_HOME/standalone/deployments/i2b2.war/WEB-INF/services
		cp $MY_PATH/features/temp/AdditionalData/serverfiles/IdrtAdditionalData-EJB.jar $JBOSS_HOME/standalone/deployments/i2b2.war/WEB-INF/lib
	fi

	dialog --colors --backtitle "$BACKTITLE" --infobox "AdditionalData: Copying web client files ..." 5 60
	sleep 1
	
	getWebserverDirectory	   
	cp -r $MY_PATH/features/temp/AdditionalData/webclientfiles/idrt $WEBSERVERDIRECTORY/webclient/js-i2b2/cells/plugins

	dialog --colors --backtitle "$BACKTITLE" --infobox "AdditionalData: Modifying i2b2_loader.js ..." 5 60
	sleep 1
	
	LOADERFILE=$WEBSERVERDIRECTORY/webclient/js-i2b2/i2b2_loader.js

	LOADERCODE="{ code: \"IdrtAdditionalData2\",\n\t\t  forceLoading: true,\n\t\t  forceConfigMsg: { DefaultTab: 0 },\n\t\t  roles: [ \"DATA_LDS\", \"DATA_DEID\", \"DATA_PROT\" ],\n\t\t  forceDir: \"cells/plugins/idrt\" \n\t\t},\n\t\t"
	
	# Add plugin to list of webclient plugins in i2b2 loader

	if ! grep -q "{ code: \"IdrtAdditionalData2\"," $LOADERFILE; then
	  sed -e "s|{ code:	\"Timeline\",|$LOADERCODE&|1" \
		  -i $LOADERFILE
	fi

	# Register cell in PM:

	dialog --colors --backtitle "$BACKTITLE" --infobox "AdditionalData: Registering cell in $PM_SCHEMA ..." 5 60
	sleep 1
	
	cd "$MY_PATH/database/"
		
	DIR="$MY_PATH/database/"
	
	if [ "$I2B2_VERSION" = "1.6.09" ]; then   # for backward compatibility
		createDBProperties $DIR $PM_SCHEMA $PM_PASS "$DB_SERVER:$DB_PORT:$ORA_SSID"
	else
		createDBProperties $DIR $PM_SCHEMA $PM_PASS
	fi

	echo "DELETE FROM PM_CELL_DATA WHERE CELL_ID = 'IdrtAdditionalData2';" > "$MY_PATH/database/scripts/database_job.sql"
	echo "COMMIT;" >> "$MY_PATH/database/scripts/database_job.sql"
	
	echo "INSERT INTO PM_CELL_DATA (CELL_ID,PROJECT_PATH,NAME,METHOD_CD,URL,CAN_OVERRIDE,CHANGE_DATE,ENTRY_DATE,CHANGEBY_CHAR,STATUS_CD) values ('IdrtAdditionalData2','/','IdrtAdditionalData2','SOAP','http://$IP_ADDR:9090/i2b2/services/IdrtAdditionalData/',1,null,null,null,'A');" >> "$MY_PATH/database/scripts/database_job.sql"
	echo "COMMIT;" >> "$MY_PATH/database/scripts/database_job.sql"
		
	checkJavaInstallation
	$ANT_HOME/bin/ant -f data_build.xml database_job 2> $MY_PATH/logs/idrt_additionaldata.err.log > $MY_PATH/logs/idrt_additionaldata.log
	rm $MY_PATH/database/scripts/database_job.sql
	
    errorHandler $LINENO "AdditionalData: Register cell in $PM_SCHEMA" $MY_PATH/logs/idrt_additionaldata.log $MY_PATH/logs/idrt_additionaldata.err.log
	
	dialog --colors --backtitle "$BACKTITLE" --infobox "AdditionalData: Checking JBoss status ..." 5 60
	sleep 1
	
	getJBossStatus
	if [ "$JBOSSSTATUS" = "1" ]; then  
		stopJBoss
		startJBoss
	fi

	cd  $MY_PATH

}


